import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CategoriesComponent } from './categories.component';
import { AuthGuard } from '../auth/auth.guard';

const routes: Routes = [{ path: 'categories', component: CategoriesComponent, canActivate: [AuthGuard] }];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      useHash: true
    }),
  ],
  exports: [RouterModule]
})
export class CategoriesRoutesModule { }
