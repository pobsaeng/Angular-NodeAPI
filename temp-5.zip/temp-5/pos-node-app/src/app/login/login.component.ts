import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastComponent } from '../shared/toast/toast.component';
import { AuthService } from '../auth/auth.service';
import { User } from '../auth/user.interface';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  email: string;
  password: string;
  isLogging = false;

  constructor(
    private router: Router,
    private toast: ToastComponent,
    private authService: AuthService) { }

  ngOnInit() { }

  enterLogin(event) {
    // enter login
    if (event.keyCode === 13) {
      this.onLogin();
    }
  }
  onLogin() {
    console.log(this.email, this.password);

    this.authService.signIn(this.email, this.password);
  }

}
