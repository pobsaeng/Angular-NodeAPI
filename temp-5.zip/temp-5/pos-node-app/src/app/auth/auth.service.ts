import { Injectable, EventEmitter } from '@angular/core';
import { Http } from '@angular/http';
import { Router } from '@angular/router';
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from 'rxjs/Rx';
import { siteMap } from '../common/sitemap';
import { User } from './user.interface';

@Injectable()
export class AuthService {

  public showNavBarEmitter: EventEmitter<boolean> = new EventEmitter<boolean>();
  private authenticated = false;

  constructor(private router: Router, private http: Http) { }

  signIn(email, password) {
    const { LOGIN_URL } = siteMap().login;

    return new Promise((resolve, reject) => {
      this.http.post(LOGIN_URL, { username: email, password: password })
        .map(res => res.json()).subscribe(data => {

          if (data.success) {
            console.log(data);
            sessionStorage.setItem('token', JSON.stringify(data.token));

            this.authenticated = true;
            this.showNavBar(true);
            this.router.navigate(['groupproduct']);

          } else {
            this.authenticated = false;
            this.showNavBar(false);
            this.router.navigate(['']);
          }
          resolve(data);

        }, error => {
          this.authenticated = false;
          this.router.navigate(['']);

          reject(error);
        });
    });
  }

  logout() {
    this.authenticated = false;
    this.showNavBar(false);
    this.router.navigate(['']);

    sessionStorage.removeItem("token");
  }

  isAuthenticated() {
    return this.authenticated;
  }

  private showNavBar(ifShow: boolean) {
    this.showNavBarEmitter.emit(ifShow);
  }

}
