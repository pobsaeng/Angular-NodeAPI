const db = require('../database/MySQL');
const PromQueries = require('../database/PromQueries');

class ProductsModel {
    constructor() {
        this.connection = db.createConnection();
        this.promQueries = new PromQueries(this.connection);
    }
    create(callback) {
        var sql = `INSERT INTO tb_product (
            product_id,
            group_product_id,
            product_code,
            product_name,
            product_detail,
            product_created_date,
            product_last_update,
            product_quantity,
            product_pack_barcode,
            product_total_per_pack,
            product_expire,
            product_return,
            product_expire_date,
            product_sale_condition)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`;

        let params = [null, 1, 'AC-0012545', 'หนังสือ NodeJS 1', '', 
        new Date(), new Date(), 10, 1200, 12000, 'fresh', 'in', new Date(), 'sale'];

        this.connection.query(`${sql}`, params, function (err, result) {
            if (err) throw err;
            callback(result);
        });
    }
    edit(params, callback) {

    }
    remove(id, callback) {

    }

}
module.exports = ProductsModel;