const db = require('../database/MySQL');

class BillSaleModel {
    constructor() {
        this.connection = db.createConnection();
    }
    create(callback) {
        var sql = `INSERT INTO tb_bill_sale (
            bill_sale_id,
            bill_sale_created_date,
            bill_sale_status,
            member_id,
            bill_sale_vat,
            user_id,
            branch_id,
            bill_sale_pay_date,
            bill_sale_drop_bill_date)
            VALUES(?,?,?,?,?,?,?,?,?)`;

        let params = [null, new Date(), 'pay', 1, 'no', 100234, 1, new Date(), new Date()];

        this.connection.query(`${sql}`, params, function (err, result) {
            if (err) throw err;
            callback(result);
        });
    }
}
module.exports = BillSaleModel;