var jwt = require('jsonwebtoken');

class Utilities {
    jwtGenerator(object, secretKey) {
        return jwt.sign(object, secretKey);  // expire in 1 week
    }
    jwtVerify(token, secretKey, callback) {
        jwt.verify(token, secretKey, function (err, decoded) {
            if (err) {
                callback(null);
            } else {
                callback(decoded);
            }
        });
    }
}
module.exports = Utilities;
